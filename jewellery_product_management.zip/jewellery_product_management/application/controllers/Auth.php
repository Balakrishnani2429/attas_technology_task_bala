<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Auth_model');
        $this->load->library('session');
    }

    // Display login view
    public function index() {
        $this->load->view('login');
    }

    // Handle login POST request
    public function login() {
        $username = $this->input->post('username');
        $password = $this->input->post('password'); // Not recommended for production

        $user = $this->Auth_model->validate_user($username, $password);

        if ($user) {
            // Store user ID in session
            $this->session->set_userdata('user_id', $user->id);
            redirect('products');
        } else {
            // Show error message
            $this->session->set_flashdata('error', 'Invalid login');
            redirect('auth');
        }
    }

    // Handle logout
    public function logout() {
        $this->session->sess_destroy();
        redirect('auth');
    }
}

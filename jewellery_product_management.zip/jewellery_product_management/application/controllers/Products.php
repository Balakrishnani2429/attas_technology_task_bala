<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('user_id')) redirect('auth');
        $this->load->model('Product_model');
    }

    public function index() {
        $this->load->view('products/list');
    }

    function frontend_view()
    {
        $data['product_details']    = $this->Product_model->get_datas('products',array());
        $this->load->view('products/frontend_view', $data);
    }

    public function get_products() {
        echo json_encode($this->Product_model->get_all_products());
    }

    public function add($id=null) {
        $data['categories'] = $this->Product_model->get_datas('categories',array());
        $product_details    = $this->Product_model->get_datas('products',array('id'=>$id));

        if(!empty($id)):
            $data['id']                 = $product_details[0]->id;
            $data['name']               = $product_details[0]->name;
            $data['description']        = $product_details[0]->description;
            $data['price']              = $product_details[0]->price;
            $data['category_id']        = $product_details[0]->category_id;
            $data['image']              = $product_details[0]->image;
        else:
            $data['id']                 = "";
            $data['name']               = "";
            $data['description']        = "";
            $data['price']              = "";
            $data['category_id']        = "";
            $data['image']              = "";
        endif;
        $this->load->view('products/form', $data);
    }

    function delete($id)
    {
        $this->db->where('id',$id);
        $this->db->delete('products');
        redirect('products');
    }
    public function save() {
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'jpg|jpeg|png';
        $this->load->library('upload', $config);

        $image = '';
        if ($this->upload->do_upload('image')) {
            $upload_data = $this->upload->data();
            $this->_resize_image($upload_data['full_path']);
            $image = $upload_data['file_name'];
        }
        else
        {
            $image = $this->input->post('ex_image');
        };
        $get_id =$this->input->post('id');
        $this->Product_model->insert([
            'name' => $this->input->post('name'),
            'description' => $this->input->post('description'),
            'price' => $this->input->post('price'),
            'category_id' => $this->input->post('category'),
            'image' => $image
        ],$get_id);

        redirect('products');
    }

    private function _resize_image($path) {
        $config['image_library'] = 'gd2';
        $config['source_image'] = $path;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = 500;
        $config['height'] = 500;
        $this->load->library('image_lib', $config);
        $this->image_lib->resize();
    }
}

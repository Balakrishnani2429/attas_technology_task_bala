<?php
// application/models/Auth_model.php
class Auth_model extends CI_Model {
    public function validate_user($username, $password) {
        return $this->db->get_where('users', ['username' => $username, 'password' => $password])->row();
    }
}

?>
<?php

// application/models/Product_model.php
class Product_model extends CI_Model {

    public function get_all_products() {
        $query = $this->db->select('p.*, c.name as category')
            ->from('products p')
            ->join('categories c', 'p.category_id = c.id')
            ->get();
        return ['data' => $query->result()];
    }

    public function get_datas($tbl,$where) {
        // return $this->db->get($tbl)->result();
        return $this->db->get_where($tbl, $where)->result();

    }

    public function insert($data,$where_id) {
        if(empty($where_id)):
            $this->db->insert('products', $data);
        else:
            $this->db->where('id', $where_id);
            $this->db->update('products',$data); // No update data provided!

        endif;
    }
}

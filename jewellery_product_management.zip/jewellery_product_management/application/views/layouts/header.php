<!DOCTYPE html>
<html>
<head>
    <title>Jewellery Admin</title>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
</head>
<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="<?= site_url('products') ?>">Jewellery Admin</a>
            </div>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="<?= site_url('products') ?>">Products</a></li>
                <li><a href="<?= site_url('products/add') ?>">Add Product</a></li>
                <li><a href="<?= site_url('auth/logout') ?>">Logout</a></li>
            </ul>
        </div>
    </nav>
    <div class="container">

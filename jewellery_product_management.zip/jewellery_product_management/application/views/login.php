<!-- application/views/login.php -->
<!DOCTYPE html>
<html>
<head><title>Login</title><link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"></head>
<body class="container">
    <h2>Login</h2>
    <?php if ($this->session->flashdata('error')) echo '<p class="text-danger">'.$this->session->flashdata('error').'</p>'; ?>
    <form method="post" action="<?= site_url('auth/login') ?>">
        <div class="form-group"><input type="text" name="username" class="form-control" placeholder="Username" required></div>
        <div class="form-group"><input type="password" name="password" class="form-control" placeholder="Password" required></div>
        <button class="btn btn-primary">Login</button>
    </form>
</body>
</html>

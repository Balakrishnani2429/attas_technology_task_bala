<?php $this->load->view('layouts/header'); ?>

    <h2>Add Product</h2>
    <form method="post" action="<?= site_url('products/save') ?>" enctype="multipart/form-data">
        <div class="form-group"><input type="text" name="name" class="form-control" value="<?=$name?>" placeholder="Product Name" required></div>
        <div class="form-group"><textarea name="description" class="form-control" value="<?=$description?>" placeholder="Description"><?=$description?></textarea></div>
        <div class="form-group"><input type="number" step="0.01" name="price" class="form-control" value="<?=$price?>" placeholder="Price" required></div>
        <div class="form-group">
            <select name="category" class="form-control" required>
                <option value="">Select Category</option>
                <?php foreach($categories as $cat): ?>
                    <?php $select_val = ($category_id ==  $cat->id)?'selected':'';?>
                    <option <?= $select_val ?> value="<?= $cat->id ?>"><?= $cat->name ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group"><input type="file" name="image" value="<?=$image?>" class="form-control"></div>
        <input type="hidden" value="<?=$id?>" name="id">
        <input type="hidden" value="<?=$image?>" name="ex_image">
        <img src="<?=str_replace('index.php',"",site_url('uploads/')).$image?>" width="60"><br><br>
        <button class="btn btn-success"><?= (!empty($id))?'Update':'Save'?></button>
    </form>
    <?php $this->load->view('layouts/footer'); ?>

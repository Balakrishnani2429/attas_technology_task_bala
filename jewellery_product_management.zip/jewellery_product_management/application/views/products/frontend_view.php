<!-- index.html -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Jewellery Shop</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .hero {
      background: url('https://images.unsplash.com/photo-1549887534-27c6f9e6c2b5') no-repeat center center;
      background-size: cover;
      height: 400px;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .hero h1 {
      background-color: rgba(0,0,0,0.5);
      padding: 20px;
      border-radius: 10px;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="#">Jewellery Shop</a>
    <a class="navbar-brand" href="<?= site_url('auth') ?>">Admin Pannel</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
  </div>
</nav>

<!-- Hero Section -->
<section class="hero text-center">
  <h1>ATTS TECHNOLOGIES PRIVATE LIMITED</h1>
</section>

<!-- Product Gallery -->
<div class="container my-5">
  <h2 class="mb-4 text-center">Our Collection</h2>
  <div class="row row-cols-1 row-cols-md-3 g-4">
    <?php foreach($product_details as $product_datas): ?>
        <!-- Product Card -->
        <div class="col">
        <div class="card h-100">
            <img src="<?=str_replace('index.php',"",site_url('uploads/')).$product_datas->image?>" class="card-img-top" alt="Necklace">
            <div class="card-body">
            <h5 class="card-title"><?=$product_datas->name?></h5>
            <p class="card-text"><?=$product_datas->description?></p>
            </div>
            <div class="card-footer text-end">
            <button class="btn btn-outline-primary"><?='$ '  . $product_datas->price?></button>
            </div>
        </div>
        </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Footer -->
<footer class="bg-dark text-white text-center p-3">
  &copy; <?= date('Y') ?> Balakrishnan Php Developer Task Deticate To ATTS.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

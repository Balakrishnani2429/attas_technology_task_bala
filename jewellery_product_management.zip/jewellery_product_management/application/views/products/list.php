<?php $this->load->view('layouts/header'); ?>

    <h2>Product List <a href="<?= site_url('products/add') ?>" class="btn btn-primary pull-right">Add Product  </a>
    <a target="_blank" style="margin-right: 10px;" href="<?= site_url('products/frontend_view') ?>" class="btn btn-success pull-right">Frontend</a>
    </h2>
    <table id="products" class="display">
        <thead>
            <tr>
                <th>Name</th><th>Description</th><th>Price</th><th>Category</th><th>Image</th><th>Action</th>
            </tr>
        </thead>
    </table>

    <script src="//code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#products').DataTable({
                "ajax": "<?= site_url('products/get_products') ?>",
                "columns": [
                    { "data": "name" },
                    { "data": "description" },
                    { "data": "price" },
                    { "data": "category" },
                    {
                        "data": "image",
                        "render": function(data){
                            return '<img src="<?=str_replace('index.php',"",site_url('uploads/'))?>'+data+'" width="60">';
                        }
                    },
                    {
                        "data": "id",
                        "render": function(id){
                            return "<a href='products/add/" + id + "' class='btn btn-primary btn-xs'>" +
                            "<span class='glyphicon glyphicon-edit'></span>" +
                            "</a> " +
                            "<a href='products/delete/" + id + "' class='btn btn-danger btn-xs' onclick='return confirm(\"Are you sure Delete This Data?\")'>" +
                            "<span class='glyphicon glyphicon-trash'></span>" +
                            "</a>";

                        }
                       
                    }
                ]
            });
        });
    </script>
<?php $this->load->view('layouts/footer'); ?>
